<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Construbase - Construindo o Futuro com Excelência</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Header -->
    <header class="header" id="header">
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <div class="logo-icon">CB</div>
                    <span class="logo-text">Construbase</span>
                </div>
                
                <!-- Desktop Navigation -->
                <nav class="nav-desktop">
                    <a href="#hero" class="nav-link">Início</a>
                    <a href="#about" class="nav-link">Sobre</a>
                    <a href="services.html" class="nav-link">Serviços</a>
                    <a href="projects.html" class="nav-link">Projetos</a>
                    <a href="#contact" class="nav-link">Contato</a>
                    <p class="nav-divider">|</p>
                    <a href="php/account.php" class="nav-link">Conta</a>
                </nav>
                
                <!-- Mobile Menu Button -->
                <button class="menu-toggle" id="menuToggle" aria-label="Toggle menu">
                    <svg class="icon-menu" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                    <svg class="icon-close hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </button>
            </div>
            
            <!-- Mobile Navigation -->
            <nav class="nav-mobile hidden" id="navMobile">
                <a href="#hero" class="nav-link-mobile">Início</a>
                <a href="#about" class="nav-link-mobile">Sobre</a>
                <a href="services.html" class="nav-link-mobile">Serviços</a>
                <a href="projects.html" class="nav-link-mobile">Projetos</a>
                <a href="#contact" class="nav-link-mobile">Contato</a>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="hero" class="hero">
        <div class="hero-image">
            <img src="https://images.unsplash.com/photo-1762049297262-4eef6d6d4d7b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjb25zdHJ1Y3Rpb24lMjBidWlsZGluZ3xlbnwxfHx8fDE3NjQ2MDM4MzN8MA&ixlib=rb-4.1.0&q=80&w=1080" alt="Construção moderna">
            <div class="hero-overlay"></div>
        </div>
        <div class="container hero-container">
            <div class="hero-content">
                <h1 class="hero-title">Construindo o Futuro com Excelência</h1>
                <p class="hero-text">
                    Há mais de 20 anos transformando sonhos em realidade através de
                    projetos de alta qualidade e compromisso com nossos clientes.
                </p>
                <div class="hero-buttons">
                    <a href="#contact" class="btn btn-primary">
                        Solicite um Orçamento
                        <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                    <a href="#projects" class="btn btn-secondary">Ver Projetos</a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <div class="about-grid">
                <div class="about-content">
                    <h2>Sobre a Construbase</h2>
                    <p class="text-gray">
                        Somos uma construtora com mais de duas décadas de experiência no
                        mercado, especializada em obras residenciais, comerciais e
                        industriais. Nossa missão é entregar projetos que superem as
                        expectativas de nossos clientes.
                    </p>
                    <p class="text-gray">
                        Contamos com uma equipe de profissionais altamente capacitados e
                        utilizamos as mais modernas tecnologias de construção para
                        garantir qualidade, segurança e sustentabilidade em cada projeto.
                    </p>
                    
                    <div class="features-list">
                        <div class="feature-item">
                            <svg class="icon-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                            <span>Equipe altamente qualificada</span>
                        </div>
                        <div class="feature-item">
                            <svg class="icon-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                            <span>Materiais de primeira qualidade</span>
                        </div>
                        <div class="feature-item">
                            <svg class="icon-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                            <span>Prazos rigorosamente cumpridos</span>
                        </div>
                        <div class="feature-item">
                            <svg class="icon-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                            <span>Acompanhamento em todas as etapas</span>
                        </div>
                    </div>
                </div>
                
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1632862378103-8248dccb7e3d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjB3b3JrZXIlMjBzaXRlfGVufDF8fHx8MTc2NDcwMjg1NXww&ixlib=rb-4.1.0&q=80&w=1080" alt="Equipe de construção">
                </div>
            </div>
            
            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <svg class="icon-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect>
                        <rect x="9" y="7" width="6" height="6"></rect>
                        <line x1="9" y1="17" x2="15" y2="17"></line>
                    </svg>
                    <div class="stat-value">500+</div>
                    <div class="stat-label">Projetos Concluídos</div>
                </div>
                <div class="stat-card">
                    <svg class="icon-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                    <div class="stat-value">200+</div>
                    <div class="stat-label">Clientes Satisfeitos</div>
                </div>
                <div class="stat-card">
                    <svg class="icon-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="8" r="7"></circle>
                        <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline>
                    </svg>
                    <div class="stat-value">20+</div>
                    <div class="stat-label">Anos de Experiência</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services">
        <div class="container">
            <div class="section-header">
                <h2>Nossos Serviços</h2>
                <p class="text-gray">
                    Oferecemos soluções completas em construção civil, desde o
                    planejamento até a entrega final do projeto.
                </p>
            </div>
            
            <div class="services-grid">
                <div class="service-card">
                    <svg class="icon-service" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                        <polyline points="9 22 9 12 15 12 15 22"></polyline>
                    </svg>
                    <h3>Construção Residencial</h3>
                    <p>Casas, sobrados e condomínios projetados e construídos com atenção aos detalhes.</p>
                </div>
                
                <div class="service-card">
                    <svg class="icon-service" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect>
                        <rect x="9" y="7" width="6" height="6"></rect>
                        <line x1="9" y1="17" x2="15" y2="17"></line>
                    </svg>
                    <h3>Construção Comercial</h3>
                    <p>Edifícios comerciais, escritórios e lojas que refletem a identidade do seu negócio.</p>
                </div>
                
                <div class="service-card">
                    <svg class="icon-service" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path>
                    </svg>
                    <h3>Construção Industrial</h3>
                    <p>Galpões, fábricas e instalações industriais com foco em funcionalidade.</p>
                </div>
                
                <div class="service-card">
                    <svg class="icon-service" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                    </svg>
                    <h3>Reformas e Ampliações</h3>
                    <p>Modernização e expansão de espaços existentes com qualidade e eficiência.</p>
                </div>
                
                <div class="service-card">
                    <svg class="icon-service" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                        <polyline points="7.5 4.21 12 6.81 16.5 4.21"></polyline>
                        <polyline points="7.5 19.79 7.5 14.6 3 12"></polyline>
                        <polyline points="21 12 16.5 14.6 16.5 19.79"></polyline>
                        <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                        <line x1="12" y1="22.08" x2="12" y2="12"></line>
                    </svg>
                    <h3>Projetos Arquitetônicos</h3>
                    <p>Desenvolvimento de projetos personalizados que atendem suas necessidades.</p>
                </div>
                
                <div class="service-card">
                    <svg class="icon-service" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <line x1="10" y1="9" x2="8" y2="9"></line>
                    </svg>
                    <h3>Acabamentos</h3>
                    <p>Serviços especializados de acabamento fino para valorizar seu imóvel.</p>
                </div>
            </div>
            
            <div class="section-cta">
                <a href="services.html" class="btn btn-primary">Ver Todos os Serviços</a>
            </div>
        </div>
    </section>

    <!-- Projects Section -->
    <section id="projects" class="projects">
        <div class="container">
            <div class="section-header">
                <h2>Projetos Realizados</h2>
                <p class="text-gray">
                    Confira alguns dos nossos principais projetos entregues com
                    excelência e dentro do prazo.
                </p>
            </div>
            
            <div class="projects-grid">
                <div class="project-card">
                    <div class="project-image">
                        <img src="https://images.unsplash.com/photo-1747555094127-9a922d56a64c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjByZXNpZGVudGlhbCUyMGJ1aWxkaW5nfGVufDF8fHx8MTc2NDYyMTg3NHww&ixlib=rb-4.1.0&q=80&w=1080" alt="Residencial Vista Verde">
                        <div class="project-badge">Residencial</div>
                    </div>
                    <div class="project-content">
                        <h3>Residencial Vista Verde</h3>
                        <p>Condomínio com 120 unidades e área de lazer completa.</p>
                    </div>
                </div>
                
                <div class="project-card">
                    <div class="project-image">
                        <img src="https://images.unsplash.com/photo-1580741753044-b3f303ad361b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tZXJjaWFsJTIwYnVpbGRpbmclMjBhcmNoaXRlY3R1cmV8ZW58MXx8fHwxNzY0NjAzOTA0fDA&ixlib=rb-4.1.0&q=80&w=1080" alt="Edifício Corporativo Horizon">
                        <div class="project-badge">Comercial</div>
                    </div>
                    <div class="project-content">
                        <h3>Edifício Corporativo Horizon</h3>
                        <p>Torre comercial de 15 andares no centro empresarial.</p>
                    </div>
                </div>
                
                <div class="project-card">
                    <div class="project-image">
                        <img src="https://images.unsplash.com/photo-1762049297262-4eef6d6d4d7b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjb25zdHJ1Y3Rpb24lMjBidWlsZGluZ3xlbnwxfHx8fDE3NjQ2MDM4MzN8MA&ixlib=rb-4.1.0&q=80&w=1080" alt="Galpão Logístico Premium">
                        <div class="project-badge">Industrial</div>
                    </div>
                    <div class="project-content">
                        <h3>Galpão Logístico Premium</h3>
                        <p>Instalação logística de 8.000m² com tecnologia de ponta.</p>
                    </div>
                </div>
            </div>
            
            <div class="section-cta">
                <a href="projects.html" class="btn btn-primary">Ver Todos os Projetos</a>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="section-header">
                <h2>Entre em Contato</h2>
                <p class="text-gray">
                    Estamos prontos para transformar seu projeto em realidade. Entre em
                    contato conosco para um orçamento sem compromisso.
                </p>
            </div>
            
            <div class="contact-grid">
                <div class="contact-info">
                    <div class="info-card">
                        <svg class="icon-contact" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                        <h3>Telefone</h3>
                        <a href="tel:+551134567890">(11) 3456-7890</a>
                    </div>
                    
                    <div class="info-card">
                        <svg class="icon-contact" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                            <polyline points="22,6 12,13 2,6"></polyline>
                        </svg>
                        <h3>E-mail</h3>
                        <a href="mailto:contato@construbase.com.br">contato@construbase.com.br</a>
                    </div>
                    
                    <div class="info-card">
                        <svg class="icon-contact" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                        <h3>Endereço</h3>
                        <a href="#">Av. Paulista, 1000 - São Paulo, SP</a>
                    </div>
                </div>
                
                <div class="contact-form-container">
                    <form id="contactForm" class="contact-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Nome Completo</label>
                                <input type="text" id="name" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="email">E-mail</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Telefone</label>
                            <input type="tel" id="phone" name="phone" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="message">Mensagem</label>
                            <textarea id="message" name="message" rows="5" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            Enviar Mensagem
                            <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="22" y1="2" x2="11" y2="13"></line>
                                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                            </svg>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-about">
                    <div class="logo">
                        <div class="logo-icon">CB</div>
                        <span class="logo-text">Construbase</span>
                    </div>
                    <p class="footer-text">
                        Construindo sonhos com excelência e compromisso há mais de 20 anos.
                    </p>
                    <div class="social-links">
                        <a href="#" class="social-link" aria-label="Facebook">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                            </svg>
                        </a>
                        <a href="#" class="social-link" aria-label="Instagram">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                            </svg>
                        </a>
                        <a href="#" class="social-link" aria-label="LinkedIn">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                                <rect x="2" y="9" width="4" height="12"></rect>
                                <circle cx="4" cy="4" r="2"></circle>
                            </svg>
                        </a>
                    </div>
                </div>
                
                <div class="footer-links">
                    <h3>Links Rápidos</h3>
                    <ul>
                        <li><a href="#hero">Início</a></li>
                        <li><a href="#about">Sobre</a></li>
                        <li><a href="#services">Serviços</a></li>
                        <li><a href="#projects">Projetos</a></li>
                    </ul>
                </div>
                
                <div class="footer-services">
                    <h3>Serviços</h3>
                    <ul>
                        <li>Construção Residencial</li>
                        <li>Construção Comercial</li>
                        <li>Reformas</li>
                        <li>Projetos Arquitetônicos</li>
                    </ul>
                </div>
                
                <div class="footer-contact">
                    <h3>Contato</h3>
                    <ul>
                        <li class="footer-contact-item">
                            <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            <span>Av. Paulista, 1000<br>São Paulo, SP</span>
                        </li>
                        <li class="footer-contact-item">
                            <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                            </svg>
                            <a href="tel:+551134567890">(11) 3456-7890</a>
                        </li>
                        <li class="footer-contact-item">
                            <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                            <a href="mailto:contato@construbase.com.br">contato@construbase.com.br</a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <span id="currentYear"></span> Construbase. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>
